const { Actor } = require('apify');
const { PlaywrightCrawler } = require('crawlee');

Actor.main(async () => {
    const input = await Actor.getInput();
    const keyword = input.keyword;

    const crawler = new PlaywrightCrawler({
        async requestHandler({ page, request, log }) {
            log.info(`Searching for: ${keyword}`);
            await page.goto('https://datawarehouse.dbd.go.th/index');

            await page.fill('input#searchKeyword', keyword);
            await page.click('button[type="submit"]');

            await page.waitForSelector('.table', { timeout: 15000 });

            const results = await page.$$eval('.table tbody tr', rows => {
                return rows.map(row => {
                    const cells = row.querySelectorAll('td');
                    return {
                        business_name: cells[1]?.innerText.trim(),
                        registration_id: cells[2]?.innerText.trim(),
                        province: cells[3]?.innerText.trim(),
                        status: cells[4]?.innerText.trim()
                    };
                });
            });

            await Actor.pushData(results);
        },
    });

    await crawler.run([{ url: 'https://datawarehouse.dbd.go.th/index' }]);
});
